import 'package:flutter/material.dart';

class InvoiceData {
  String invoiceNumber;
  String customerName;
  double amount;

  InvoiceData({
    required this.invoiceNumber,
    required this.customerName,
    required this.amount,
  });
}

class InvoiceView extends StatelessWidget {
  final InvoiceData invoiceData;
  final VoidCallback onEdit;

  const InvoiceView({Key? key, required this.invoiceData, required this.onEdit}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Text('Invoice Number: ${invoiceData.invoiceNumber}', style: TextStyle(fontSize: 18)),
          SizedBox(height: 8),
          Text('Customer Name: ${invoiceData.customerName}', style: TextStyle(fontSize: 18)),
          SizedBox(height: 8),
          Text('Amount: \$${invoiceData.amount.toStringAsFixed(2)}', style: TextStyle(fontSize: 18)),
          SizedBox(height: 16),
          ElevatedButton(
            onPressed: onEdit,
            child: Text('Edit Invoice'),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'invoice_view.dart';

class EditInvoiceScreen extends StatefulWidget {
  final InvoiceData invoiceData;

  const EditInvoiceScreen({Key? key, required this.invoiceData}) : super(key: key);

  @override
  _EditInvoiceScreenState createState() => _EditInvoiceScreenState();
}

class _EditInvoiceScreenState extends State<EditInvoiceScreen> {
  late TextEditingController _invoiceNumberController;
  late TextEditingController _customerNameController;
  late TextEditingController _amountController;

  @override
  void initState() {
    _invoiceNumberController = TextEditingController(text: widget.invoiceData.invoiceNumber);
    _customerNameController = TextEditingController(text: widget.invoiceData.customerName);
    _amountController = TextEditingController(text: widget.invoiceData.amount.toString());
    super.initState();
  }

  @override
  void dispose() {
    _invoiceNumberController.dispose();
    _customerNameController.dispose();
    _amountController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Edit Invoice'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            TextField(
              controller: _invoiceNumberController,
              decoration: InputDecoration(labelText: 'Invoice Number'),
            ),
            TextField(
              controller: _customerNameController,
              decoration: InputDecoration(labelText: 'Customer Name'),
            ),
            TextField(
              controller: _amountController,
              decoration: InputDecoration(labelText: 'Amount'),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                // Save the edited invoice data
                Navigator.pop(context);
              },
              child: Text('Save'),
            ),
          ],
        ),
      ),
    );
  }
}

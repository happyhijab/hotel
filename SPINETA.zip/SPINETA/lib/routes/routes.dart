class RoutesName {
  static const String Splash = "/";
  static const String IntroductionScreen = '/introductionScreen';
  static const String Login = '/masuk';
  static const String Home = '/home';
  static const String TabScreen = "/bottomTab/bottomTabScreen";
}

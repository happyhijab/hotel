import 'package:flutter/material.dart';

GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

List<Map<String, String>>? allTexts; // we store all text in this variable

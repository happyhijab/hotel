class RoomData {
  int numberRoom;

  int people;

  RoomData(this.numberRoom, this.people);
}

class DateText {
  late int startDate;
  late int endDate;

  DateText(this.startDate, this.endDate);
}

class PeopleSleeps {
  int peopleNumber;
  PeopleSleeps(this.peopleNumber);
}
